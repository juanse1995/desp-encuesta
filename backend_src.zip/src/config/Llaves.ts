export namespace Llaves {
  export const claveJWT = 'JWTMIGRANTES2022*';
}
